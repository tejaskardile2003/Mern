const {studentmodal,servicemodal,adminmodal} = require('./modal')
const cartmodal = require('./modal2');
const studentmodal1 = require('./modal3');
const studentmodal2 = require('./modal4');
const studentmodal3 = require('./modal5');



const adduser=async(req,res)=>{
     const { Name,Email,Username,Password,PhoneNo, Address}=req.body;

     try{
        const userdata = new studentmodal({
            Name,Email,Username,Password,PhoneNo, Address
        })
        const data = await userdata.save()

        res.status(200).send({data})
     }
     catch(err){
            console.log(err)
            res.status(400).send({err})
    
     }
}

const getdata= async(req,res)=>{
    try{
        const userdata= await studentmodal.find()
    res.status(200).send({userdata})
    }
    catch(err){
        console.log(err);
        res.status(400).send({err})
    }
}

const updateuser = async (req, res) => {
    try {
        const { Username } = req.params
        const { Name,Email,Password,PhoneNo, Address} = req.body
        const data = await studentmodal.updateOne(
            { Username },
            {
                $set: { Name,Email,Password,PhoneNo, Address}
            }
        )
        if (data.modifiedCount > 0) {
            res.status(200).send({ msg: "data update sucessfully" })
        }
        else {
            res.status(400).send({ msg: "data not update sucessfully" })
        }
    } catch (err) {
        console.log(err);
        res.status(500).send({ msg: "user not found" })
    }
}

const finduserbyId = async(req,res)=>{
    try{
        const {Username} = req.params
        const {Name,Email,PhoneNo, Address}= req.body

        const data = await studentmodal.findOne({Username})
        res.status(200).send({data, msg:"user found"})
    }
    catch(err){
        res.status(400).send({err})
    }
    
}

const deleteuser =async(req,res)=>{

    try{
        const {Username}=req.params
        const data= await studentmodal.deleteOne({Username})
        if (data.deletedCount > 0) {
            res.status(200).send({ msg: "data delete sucessfully" })
        }
        else {
            res.status(400).send({ msg: "data not delete sucessfully" })
        }
    }
    catch(err){
        res.status(400).send(err)
    }

} 

const deletcard1 =async(req,res)=>{

    try{
        const {Product}=req.params
        const data= await studentmodal1.deleteOne({Product})
        if (data.deletedCount > 0) {
            res.status(200).send({ msg: "data delete sucessfully" })
        }
        else {
            res.status(400).send({ msg: "data not delete sucessfully" })
        }
    }
    catch(err){
        res.status(400).send(err)
    }

} 

const deletcard2 =async(req,res)=>{

  try{
      const {Product}=req.params
      const data= await studentmodal2.deleteOne({Product})
      if (data.deletedCount > 0) {
          res.status(200).send({ msg: "data delete sucessfully" })
      }
      else {
          res.status(400).send({ msg: "data not delete sucessfully" })
      }
  }
  catch(err){
      res.status(400).send(err)
  }

} 

const deletcard3 =async(req,res)=>{

  try{
      const {Product}=req.params
      const data= await studentmodal3.deleteOne({Product})
      if (data.deletedCount > 0) {
          res.status(200).send({ msg: "data delete sucessfully" })
      }
      else {
          res.status(400).send({ msg: "data not delete sucessfully" })
      }
  }
  catch(err){
      res.status(400).send(err)
  }

} 
const getadmin = async (req, res) => {
    
  
    try {
        const { username, password } = req.body;
      const user = await adminmodal.findOne({ username });
  
      if (!user) {
        return res.status(401).send('Invalid credentials');
      }
  
    //   const passwordMatch = await comparePassword(password, user.password);
    const passwordMatch = password === user.password;

      if (passwordMatch) {
        res.send('Login successful');
 
      } else {
        res.status(401).send('Invalid credentials');
      }
    } catch (err) {
      console.error(err);
      res.status(500).send({ msg: 'Internal Server Error' });
    }
  };


//****************************** Vivek *************************

const addproduct = async (req, res) => {
    const {  
      Id ,
      Product,
      Price
    } = req.body;
    try {
      const userdata = new servicemodal({
         Id,
         Product,
         Price
      })
  
      const data = await userdata.save()
      res.status(200).send({ data })
    } catch (err) {
      console.log(err)
      res.status(400).send({ err })
    }
  }

  const getcard= async(req,res)=>{
    try{
        const userdata= await servicemodal.find()
    res.status(200).send({userdata})
    }
    catch(err){
        console.log(err);
        res.status(400).send({err})
    }
 }
 
 const addcricket = async (req, res) => {
    const {  
      Id ,
      Product,
      Price
    } = req.body;
    try {
      const userdata = new studentmodal1({
         Id,
         Product,
         Price
      })
  
      const data = await userdata.save()
      res.status(200).send({ data })
    } catch (err) {
      console.log(err)
      res.status(400).send({ err })
    }
  }
  
  const addbadminton = async (req, res) => {
    const {  
      Id ,
      Product,
      Price
    } = req.body;
    try {
      const userdata = new studentmodal2({
         Id,
         Product,
         Price
      })
  
      const data = await userdata.save()
      res.status(200).send({ data })
    } catch (err) {
      console.log(err)
      res.status(400).send({ err })
    }
  }
  
  
  const addfootball = async (req, res) => {
    const {  
      Id ,
      Product,
      Price
    } = req.body;
    try {
      const userdata = new studentmodal3({
         Id,
         Product,
         Price
      })
  
      const data = await userdata.save()
      res.status(200).send({ data })
    } catch (err) {
      console.log(err)
      res.status(400).send({ err })
    }
  }
  
  const addToCart = async (req, res) => {
    const { Id, Product, Price,Noitem } = req.body;
  
    try {
      const cartItem = new cartmodal({ Id, Product, Price , Noitem});
      const savedItem = await cartItem.save();
      res.status(200).send(savedItem);
    } catch (err) {
      console.error(err);
      res.status(500).send({ error: "Error saving item to the cart" });
    }
  };
  
  const getdata1 = async(req,res) => {
    try{
      const userdata=await studentmodal1.find()
      res.status(200).send({userdata})
    }catch(err){
      console.log(err);
      res.status(400).send({err})
    }
    
    }
  
    const getdata2 = async(req,res) => {
      try{
        const userdata=await studentmodal2.find()
        res.status(200).send({userdata})
      }catch(err){
        console.log(err);
        res.status(400).send({err})
      }
      
      }
   
      const getdata3 = async(req,res) => {
        try{
          const userdata=await studentmodal3.find()
          res.status(200).send({userdata})
        }catch(err){
          console.log(err);
          res.status(400).send({err})
        }
        
        }


  //********************************* Pratik *******************
  const getproduct=async(req,res)=>{
    try{
    const userdata=await cartmodal.find()
    res.status(200).send({userdata})
    }
    catch(err){
        console.log(err);
        res.status(400).send({err})
}
}

const deletproduct=async(req,res)=>{
  try{
      const{Id}=req.params
      const data1=await cartmodal.deleteOne({Id})
     
          res.status(200).send({msg:"data deleted sucessfully"})

  }catch(err){
      console.log(err);
      res.status(500).send({msg:"data not foune"})
  }
}
module.exports={adduser,getdata,updateuser,finduserbyId,deleteuser,deletcard1,deletcard2,deletcard3,getadmin,addproduct,getcard,addcricket,addbadminton,addfootball,addToCart,getdata1,getdata2,getdata3,getproduct,deletproduct}