const mongoose=require("mongoose")

const productdetail = mongoose.Schema({

    
    
    Id:String,
    Product:String,
    Price:Number,
    Noitem:Number
    
})


module.exports= mongoose.model('footballproduct',productdetail)