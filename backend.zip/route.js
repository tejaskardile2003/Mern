const express = require('express')

const studcontroller = require('./controller')

const route= express.Router()

route.post('/register',studcontroller.adduser)
route.get('/findall',studcontroller.getdata)
route.put('/update/:Username',studcontroller.updateuser)
route.delete('/delete/:Username',studcontroller.deleteuser)
route.delete('/delet1/:Product',studcontroller.deletcard1)
route.delete('/delet2/:Product',studcontroller.deletcard2)
route.delete('/delet3/:Product',studcontroller.deletcard3)

route.get('/finduser/:Username',studcontroller.finduserbyId)
route.post('/adminlogin',studcontroller.getadmin)
//vivek
route.post('/product',studcontroller.addproduct)
route.get('/findcard',studcontroller.getcard)

route.post('/addcric',studcontroller.addcricket)
route.post('/addbad',studcontroller.addbadminton)
route.post('/addfoot',studcontroller.addfootball)
route.post('/addprod', studcontroller.addToCart)

route.get('/findcric',studcontroller.getdata1)
route.get('/findbad',studcontroller.getdata2)
route.get('/findfoot',studcontroller.getdata3)
//pratik
route.get('/shopcart',studcontroller.getproduct)
route.delete('/del/:Id',studcontroller.deletproduct)

module.exports=route