const mongoose = require("mongoose")

const studentSchema = mongoose.Schema({

    Name:String,
    Email:String,
    Username:String,
    Password:String,
    PhoneNo:Number,
    Address:String,
    // productname:String,
    // price:Number,
    // detail:String,
   
    
});

const serviceSchema=mongoose.Schema({
    Id:String, 
    Product:String,
    Price:Number,
});

const cartSchema=mongoose.Schema({
    name:String,
    quantity:Number,
    price:Number
});

const adminSchema=mongoose.Schema({
    username:String,
    password:String
})

// module.exports=mongoose.model('detailproduct',studentSchema)

const studentmodal=mongoose.model('detailproduct',studentSchema);

const cartmodal =mongoose.model('cartproduct',cartSchema);

const servicemodal=mongoose.model('serviceproduct',serviceSchema);

const adminmodal=mongoose.model('adminlogin',adminSchema);

module.exports={studentmodal,cartmodal,servicemodal,adminmodal};

