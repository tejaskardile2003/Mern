import React from 'react'
import Col from 'react-bootstrap/esm/Col';
import Container from 'react-bootstrap/esm/Container';
import Row from 'react-bootstrap/Row';
import Card from 'react-bootstrap/Card';
import Slider from "react-slick";
import Product1 from './images/imag1.jpeg';
import Product3 from './images/imag3.jpeg';
import Product4 from './images/imag4.jpg';
import Product10 from './images/imag10.jpg';
import Product11 from './images/imag11.jpg';
import Product23 from './images/imag23.jpg';
import categ1 from './images/cate3.jpg';
import categ5 from './images/cate3.jpg';
import categ6 from './images/cate7.webp';
import categ7 from './images/cate3.jpg';
import Carousel from 'react-multi-carousel';
import Cricket from './Cricket';
import {Link} from 'react-router-dom';
const Categories = () => {


  return (
    <div>

        <br></br>&nbsp;
        <h2 style={{paddingLeft:"20px"}}>Sport Categories</h2>
        <br></br>
        <br></br>
      <Container>
        <Row >
          
            <Col md={2}>
            <Card>
            <Link to="/services" style={{padding:"15px", color:"black" ,textDecoration: 'none',fontFamily:"sans-serif"}  } className="hoverimg"><Card.Img variant="top" src={Product3} className='img '/></Link>

                {/* <a href="https://maps.app.goo.gl/juLSa8EYzWAPQ2QH8" className="hoverimg"><Card.Img variant="top" src={Product3} className='img '/></a> */}
            </Card>
            <Link to="/services" style={{textDecoration: 'none'} } className="imaglink">BasketBall</Link>
            </Col>
            
            <Col md={2}>
            <Card>
            <Link to="/services" style={{padding:"15px", color:"black" ,textDecoration: 'none',fontFamily:"sans-serif"}  } className="hoverimg"><Card.Img variant="top" src={Product4} className='img '/></Link>
            </Card>
            {/* <Link to="/cricket" style={{padding:"15px", color:"black" ,textDecoration: 'none',fontFamily:"sans-serif"} }>Cricket</Link> */}

            <Link to="/services" style={{textDecoration: 'none'} } className="imaglink">Cricket</Link>
            </Col>

            <Col md={2}>
            <Card>
            <Link to="/services" style={{padding:"15px", color:"black" ,textDecoration: 'none',fontFamily:"sans-serif"}  } className="hoverimg"><Card.Img variant="top" src={Product10} className='img '/></Link>
            </Card>
            <Link to="/services" style={{textDecoration: 'none'} } className="imaglink">Tabletennis</Link>
            </Col>

            <Col md={2}>
            <Card>
            <Link to="/services" style={{padding:"15px", color:"black" ,textDecoration: 'none',fontFamily:"sans-serif"}  } className="hoverimg"><Card.Img variant="top" src={Product11} className='img '/></Link>
            </Card>
            <Link to="/services" style={{textDecoration: 'none'} } className="imaglink">VollyBall</Link>
            </Col>

            <Col md={2}>
            <Card>
            <Link to="/services" style={{padding:"15px", color:"black" ,textDecoration: 'none',fontFamily:"sans-serif"}  } className="hoverimg"><Card.Img variant="top" src={Product1} className='img '/></Link>
            </Card>
            <Link to="/services" style={{textDecoration: 'none'} } className="imaglink">Badminton</Link>
            </Col>

            <Col md={2}>
            <Card>
            <Link to="/services" style={{padding:"15px", color:"black" ,textDecoration: 'none',fontFamily:"sans-serif"}  } className="hoverimg"><Card.Img variant="top" src={Product23} className='img '/></Link>
            </Card>
            <Link to="/services" style={{textDecoration: 'none'} } className="imaglink">FootBall</Link>
            </Col>
             
             
           
        </Row>
        

       
      </Container>
    
    </div>
  )
}




export default Categories
