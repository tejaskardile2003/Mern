import React, { useEffect, useState } from 'react'
import axios from 'axios'
import Container from 'react-bootstrap/Container';
import Product1 from './images/imag1.jpeg';
import Card from 'react-bootstrap/Card';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Button from 'react-bootstrap/Button';
const Effectexample = () => {

    const [data1,setdata]=useState([])

    useEffect(()=>{
        axios.get("https://jsonplaceholder.typicode.com/todos/")
        .then(res=>{
            console.log(res.data);
            setdata(res.data)
        })

        .catch(err =>{
            console.log(err);
        })
    })

  return (
    <div>
    <Container>
      <Row>
  {
    data1.map((a)=>{
        return(
                <>
                    <Col md={3}>
                        <Card >
                            <Card.Img variant="top" src={Product1} />
                            <Card.Body>
                              <Card.Title>{a.id}</Card.Title>
                              <Card.Text> {a.title}</Card.Text>
                              <Button variant="dark">Add to cart</Button>
                            </Card.Body>
                           
                        </Card>
                      </Col>       
                </>
            
        )
    })
  }
  
   </Row>
   

  </Container>
</div>
  )
}

export default Effectexample
