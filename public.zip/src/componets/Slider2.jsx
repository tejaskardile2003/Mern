// import { useState } from 'react';
// import React from 'react';
// import Carousel from 'react-bootstrap/Carousel';
// import Pic from '../slid1.png'
// import Pic1 from '../slid2.png'
// import Pic2 from '../slid4.png'
// import '../App.css';
// import Button from 'react-bootstrap/Button';
 import AnchorLink from 'react-anchor-link-smooth-scroll';



// function ControlledCarousel() {
//   const [index, setIndex] = useState(0);



//   const handleSelect = (selectedIndex) => {
//     setIndex(selectedIndex);

//     // const handleBuyNowClick = () => {
//     //     // Navigate to the desired destination
//     //     <AnchorLink href="#find"/>
   
//     //     // return(<div>a</div> );
//     //  };
   
        

//   return (

    
//     <Carousel activeIndex={index} onSelect={handleSelect}>
//       <Carousel.Item>
//         <img className='br'  src={Pic}/>
//         <Carousel.Caption>

//         {/* <Button variant="outline-secondary" onClick={handleBuyNowClick}>Secondary</Button>{' '} */}
//           {/* <h3>First slide label</h3> */}
//           {/* <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p> */}
//         </Carousel.Caption>
//       </Carousel.Item>
//       <Carousel.Item>
//       <img className='br' src={Pic1}/>
//         <Carousel.Caption>
//           {/* <h3>Second slide label</h3>
//           <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p> */}
//         </Carousel.Caption>
//       </Carousel.Item>

//       <Carousel.Item>
//       <img className='br' src={Pic2}/>
//         <Carousel.Caption>
//           {/* <h3>Third slide label</h3>
//           <p>
//             Praesent commodo cursus magna, vel scelerisque nisl consectetur.
//           </p> */}
//         </Carousel.Caption>
//       </Carousel.Item>
//     </Carousel>


   


//   );

 


// }}

// export default ControlledCarousel;
import Container from 'react-bootstrap/Container';
import { useState } from 'react';
import Carousel from 'react-bootstrap/Carousel';
import Pic from '../racket.png'
import Pic1 from '../shuttle.png'
import Pic2 from '../ball.png'
import Button from 'react-bootstrap/Button';
import '../App.css';

function ControlledCarousel() {
  const [index, setIndex] = useState(0);

  const handleSelect = (selectedIndex) => {
    setIndex(selectedIndex);
  };

    //   const handleBuyNowClick = () => {
    //     // Navigate to the desired destination
    //     <AnchorLink href='#find'/>
   
    //     return(<div>adscccccccccccccc</div> );
    //  };

  return (
    <Container>
    <Carousel activeIndex={index} onSelect={handleSelect}>
      <Carousel.Item>
        <img className='br'  src={Pic2}/>
        <Carousel.Caption>
            
        <AnchorLink href="#find">
        <Button variant="outline-warning">Shop Now</Button>{' '}
                </AnchorLink>
        {/* onClick={handleBuyNowClick} */}
          {/* <h3>First slide label</h3> */}
          {/* <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p> */}
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
      <img className='br' src={Pic1}/>
        <Carousel.Caption>
        <AnchorLink href="#find1">
        <Button variant="outline-warning">Shop Now</Button>{' '}
                </AnchorLink>
          {/* <h3>Second slide label</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p> */}
        </Carousel.Caption>
      </Carousel.Item>

      <Carousel.Item>
      <img className='br' src={Pic}/>
        <Carousel.Caption>
        <AnchorLink href="#find">
        <Button variant="outline-warning">Shop Now</Button>{' '}
                </AnchorLink>
          {/* <h3>Third slide label</h3>
          <p>
            Praesent commodo cursus magna, vel scelerisque nisl consectetur.
          </p> */}
        </Carousel.Caption>
      </Carousel.Item>
    </Carousel>
    </Container>

  );


  
}

export default ControlledCarousel;