import React, { useEffect, useState } from 'react'
import axios from 'axios'
import Container from 'react-bootstrap/Container';
import Product1 from './images/imag1.jpeg';
import Card from 'react-bootstrap/Card';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Button from 'react-bootstrap/Button';
const Effectexa3 = () => {

    const [data1,setdata]=useState([])

    useEffect(()=>{
        axios.get("https://jsonplaceholder.typicode.com/comments/")
        .then(res=>{
            console.log(res.data);
            setdata(res.data)
        })

        .catch(err =>{
            console.log(err);
        })
    })

  return (
    <div>
    <Container>
      <Row>
  {
    data1.map((a)=>{
        return(
                <>
                    <Col md={3}>
                        <Card >
                            <Card.Body>
                              <Card.Title>{a.email}</Card.Title>
                              <Card.Text> {a.name}</Card.Text>
                              <Button variant="dark">Add to cart</Button>
                            </Card.Body>
                           
                        </Card>
                      </Col>       
                </>
            
        )
    })
  }
  
   </Row>
   

  </Container>
</div>
  )
}

export default Effectexa3
