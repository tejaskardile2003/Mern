import React from 'react'

const User = () => {
  return (
    <div>
      <table>
        <tr>
            <th>Fisratname</th>
            <th>Lastname</th>
            <th>Email</th>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td></td>
        </tr>
      </table>
    </div>
  )
}

export default User
