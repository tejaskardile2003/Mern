import React, { useEffect, useState } from 'react'
import axios from 'axios'
import Container from 'react-bootstrap/Container';
import Product1 from './images/imag1.jpeg';
import Card from 'react-bootstrap/Card';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Button from 'react-bootstrap/Button';
import Table from 'react-bootstrap/Table';
const Tabledelet = () => {


    const [data, setdata] = useState([])

    useEffect(() => {
        axios.get("http://localhost:8000/abc/findall")
            .then(res => {
                console.log(res.data);
                setdata(res.data.userdata)
            })

            .catch(err => {
                console.log(err);
            })
    }, [])

    // function handledelete(email){
    //     axios.delete(`http://localhost:8000/abc/delete/${Username}`)
    //     .then(res => {
    //         console.log(res.data);
    //         setdata(prevData => prevData.filter(item => item.Username !== Username));
    //     })

    //     .catch(err => {
    //         console.log(err);
    //     })
    // }
    return (
        <div>

            <>
                <div>
                <Table striped bordered hover>
                        <tr>
                            <th>Username</th>
                            <th>Name</th>
                            <th>Address</th>
                            <th>PhoneNo</th>
                        </tr>
                        {
                            data.map((a) => {
                                return (
                                    <tr>
                                        <td>{a.Username}</td>
                                        <td>{a.Name}</td>
                                        <td>{a.Address}</td>
                                        <td>{a.PhoneNo}</td>
                                        {/* <td><button onClick={ ()=>{ handledelete(a.Username)}}>Delete</button></td> */}
                                    </tr>
                                )
                            })
                        }
                        
                    </Table>
                </div>
            </>

        </div>
    )
}



export default Tabledelet

