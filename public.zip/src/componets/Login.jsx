 import { useState } from 'react';
import React from 'react';
import pic1 from './images/login.jpg';
import {Link} from 'react-router-dom'
import home from './Home'
const Login = () => {
  const [loginData, setLoginData] = useState({
    username: '',
    password: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setLoginData({ ...loginData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // You can add your login logic here, for example, send the loginData to a server.

    // For demonstration purposes, we'll just log the loginData to the console.
    console.log(loginData);
  };

  return (
    <div >
       
      <img
        src={pic1} // Replace with the path to your image
        alt="Login Page Image"
        style={{ margin:'40px 0 0 0 ' , width: '45%', height: '50%' }}
      />
     
      <form onSubmit={handleSubmit} style={{ position: 'absolute', top: '50%', left: '65%',border:'2px', transform: 'translate(-50%, -50%)', padding: '50px', borderRadius: '8px' ,}}>
      <center><h2 style={{margin:'0 0 3% 10%'}}>Login</h2></center>
      <tr>
          <td>
          <label style={{padding:'20px 0 20px 0px'}}>Username :  </label>
          </td>
          <td>
          <input type="text" name="username" value={loginData.username} onChange={handleChange} />
       
          </td>
      </tr>
      
        
          
        <tr>

          <td>
          <label> Password : </label>
            
          </td>

          <td>
          <input type="password" name="password" value={loginData.password} onChange={handleChange} />
      
          </td>
        </tr>
        
          <tr>
            <td colSpan={2}>
            <Link to="/home"><button type="submit" style={{ position:'relative', top:'40px' ,left:'40%',borderRadius:"30px",height:'20%',width:'40%' ,backgroundColor:"#2F58CD", color:"white"}}>Login</button></Link>
        
            </td>
          
          </tr>

      </form>
     
    </div>
  );
};

export default Login;