import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Container, Row, Col, Card, Button } from 'react-bootstrap';
import Product1 from './images/football.webp';
import '../App.css';

const Map = () => {
  const [data1, setdata] = useState([]);
  const [itemCounts, setItemCounts] = useState({});

  const fetchData = async () => {
    try {
      const res = await axios.get('http://localhost:8000/abc/findfoot');
      setdata(res.data.userdata);

      // Initialize counts for each item
      const initialCounts = res.data.userdata.reduce((acc, item) => {
        acc[item.Product] = 0;
        return acc;
      }, {});
      setItemCounts(initialCounts);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchData(); // Initial data fetch

    // Refresh data every 10 seconds
    const intervalId = setInterval(() => {
      fetchData();
    }, 10000);

    // Cleanup the interval when the component is unmounted
    return () => clearInterval(intervalId);
  }, []);

  const addtocart = (productId, product, price, noitem) => {
    const requestData = {
      Id: productId,
      Product: product,
      Price: price,
      Noitem: noitem,
    };

    axios
      .post('http://localhost:8000/abc/addprod', requestData)
      .then((res) => {
        console.log(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const handleCountChange = (itemId, newCount) => {
    // Ensure that the new count is greater than or equal to zero
    const updatedCount = Math.max(0, newCount);

    setItemCounts((prevCounts) => ({
      ...prevCounts,
      [itemId]: updatedCount,
    }));
  };

  return (
    <div>
      <Container>
        <Row>
          {data1.map((a) => {
            const itemId = a.Product;

            return (
              <Col md={3} key={itemId}>
                <Card style={{ width: '19rem', marginBottom: '30px', marginTop: '30px' }} className="cards">
                  <Card.Img variant="top" src={Product1} />
                  <Card.Body>
                    <Card.Title style={{ fontSize: '30px' }}>{a.Product}</Card.Title>
                    <Card.Text style={{ fontSize: '25px' }}>{a.Price}</Card.Text>
                    <Row>
                      <h6>No. of item</h6>
                      <br />
                      <Col>
                        <Button
                          variant="outline-secondary"
                          size="sm"
                          onClick={() => handleCountChange(itemId, itemCounts[itemId] - 1)}
                        >
                          -
                        </Button>
                      </Col>
                      <Col>
                        <h3>{itemCounts[itemId] || 0}</h3>
                      </Col>
                      <Col>
                        <Button
                          variant="outline-secondary"
                          size="sm"
                          onClick={() => handleCountChange(itemId, itemCounts[itemId] + 1)}
                        >
                          +
                        </Button>
                      </Col>
                    </Row>
                    <Button
                      type="submit"
                      variant="primary"
                      onClick={() => addtocart(a.Id, a.Product, a.Price, itemCounts[itemId])}
                    >
                      Add to Cart
                    </Button>
                  </Card.Body>
                </Card>
              </Col>
            );
          })}
        </Row>
      </Container>
    </div>
  );
};

export default Map;
