import React from 'react'
import { useState } from 'react'

const Demo = () => {

  const [count,setcount] =useState(0)
  const [text,settext] =useState("Hello")
  return (
    <div>
      <center>
      <br></br>
      <br></br>
      <button onClick={()=>{setcount(count+2)}}>Increment</button>
      <br></br>
      <br></br>
      <button onClick={()=>{setcount(count-2)}}>Decrement</button>
      <h2>{count}</h2>

      <br></br>

      <h2>{text}</h2>
      <button onClick={()=>{settext("Welcome")}}>ChangeText</button>
      </center>
    </div>
  )
}

export default Demo
