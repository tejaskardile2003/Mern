import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';
import React from "react";
import Carousel from 'react-bootstrap/Carousel';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Container from 'react-bootstrap/Container';
import 'bootstrap/dist/css/bootstrap.min.css';
import Badge from 'react-bootstrap/Badge';
import Product1 from './images/imag1.jpeg';
import Product2 from './images/imag2.jpg';
import Product3 from './images/imag3.jpeg';
import Product4 from './images/imag4.jpg';
import Product5 from './images/imag5.jpg';
import Product6 from './images/imag6.jpg';
import Product7 from './images/imag7.jpg';
import Product8 from './images/imag8.jpg';
import Product9 from './images/imag9.jpg';
import Product10 from './images/imag10.jpg';
import Product11 from './images/imag11.jpg';
import Product12 from './images/imag12.jpg';
import Rightcor from './images/rr.png';
import {Link} from 'react-router-dom';
import pic1 from './images/b.jpg'
import pic2 from './images/basket.jpeg'
function Home() {
  return (
  
    <Container>
     <br></br>
    <br></br>
    <Carousel slide={false}>
      <Carousel.Item>
       <img src={pic1} alt="Picture(1)" width={"100%" } />
        <Carousel.Caption>
          {/* <h3>First slide label</h3> */}
          {/* <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p> */}
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
        <img src={pic2} alt="Picture(2)" width={"100%" } />
        <Carousel.Caption>
          {/* <h3>Second slide label</h3> */}
          {/* <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p> */}
        </Carousel.Caption>
      </Carousel.Item>
      
    </Carousel>


    <br></br>
    <br></br>
    <Row>
    <Col md={3}>
      <Card >
        <Card.Img variant="top" src={Product1} />
        <Card.Body>
          <Card.Title>Badminton</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
          <Button variant="dark">Add to cart</Button>
        </Card.Body>
      </Card>
      </Col>

      <Col md={3}>
      <Card >
        <Card.Img variant="top" src={Product2} />
        <Card.Body>
          <Card.Title>Ball</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
          <Button variant="dark">Add to cart</Button>
        </Card.Body>
      </Card>
      </Col>

      <Col md={3}>
      <Card >
        <Card.Img variant="top" src={Product3} />
        <Card.Body>
          <Card.Title>Basket Ball</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
          <Button variant="dark">Add to cart</Button>
        </Card.Body>
      </Card>
      </Col>

      <Col md={3}>
      <Card >
        <Card.Img variant="top" src={Product4} />
        <Card.Body>
          <Card.Title>Bat</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
          <Button variant="dark">Add to cart</Button>
        </Card.Body>
      </Card>
      </Col>
    </Row>
    
    <br></br>
    <br></br>
    <Row>
    <Col md={3}>
      <Card >
        <Card.Img variant="top" src={Product5} />
        <Card.Body>
          <Card.Title>Gloves</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
          <Button variant="dark">Add to cart</Button>
        </Card.Body>
      </Card>
      </Col>

      <Col md={3}>
      <Card >
        <Card.Img variant="top" src={Product6} />
        <Card.Body>
          <Card.Title>Rugby</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
          <Button variant="dark">Add to cart</Button>
        </Card.Body>
      </Card>
      </Col>

      <Col md={3}>
      <Card >
        <Card.Img variant="top" src={Product7} />
        <Card.Body>
          <Card.Title>Shuttle</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
          <Button variant="dark">Add to cart</Button>
        </Card.Body>
      </Card>
      </Col>

      <Col md={3}>
      <Card >
        <Card.Img variant="top" src={Product8} />
        <Card.Body>
          <Card.Title>Rope Skipping</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
          <Button variant="dark">Add to cart</Button>
        </Card.Body>
      </Card>
      </Col>
    </Row>
    
   <br></br>
    <br></br>

    <Row>
    <Col md={3}>
      <Card >
        <Card.Img variant="top" src={Product9} />
        <Card.Body>
          <Card.Title>Stumps</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
          <Button variant="dark">Add to cart</Button>
        </Card.Body>
      </Card>
      </Col>

      <Col md={3}>
      <Card >
        <Card.Img variant="top" src={Product10} />
        <Card.Body>
          <Card.Title>Tabletennis Racket</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
          <Button variant="dark">Add to cart</Button>
        </Card.Body>
      </Card>
      </Col>

      <Col md={3}>
      <Card >
        <Card.Img variant="top" src={Product11} />
        <Card.Body>
          <Card.Title>Volly Ball</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
          <Button variant="dark">Add to cart</Button>
        </Card.Body>
      </Card>
      </Col>

      <Col md={3}>
      <Card >
        <Card.Img variant="top" src={Product12} />
        <Card.Body>
          <Card.Title>Pad</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
          <Button variant="dark">Add to cart</Button>
        </Card.Body>
      </Card>
      </Col>
    </Row>

    <br></br>
    <br></br>

    <center>
      <h2>
     <Badge bg="dark"><Link to="/moreproducts" style={{ color:"white"} }>MoreProducts</Link> 
     <img src={Rightcor} alt="" width={"4%"}/>
     
     </Badge>
      </h2>
      </center>
    </Container>
  );
}

export default Home;
