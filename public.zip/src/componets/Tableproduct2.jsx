import React, { useEffect, useState } from 'react'
import axios from 'axios'
import Container from 'react-bootstrap/Container';
import Product1 from './images/imag1.jpeg';
import Card from 'react-bootstrap/Card';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Button from 'react-bootstrap/Button';
import Table from 'react-bootstrap/Table';

const Tableproduct2 = () => {

    
    const [data, setdata] = useState([])

    useEffect(() => {
        axios.get("http://localhost:8000/abc/findbad")
            .then(res => {
                console.log(res.data);
                setdata(res.data.userdata)
            })

            .catch(err => {
                console.log(err);
            })

            
    }, [])

    
    function handledelete(Product){
        axios.delete(`http://localhost:8000/abc/delet2/${Product}`)
        .then(res => {
            console.log(res.data);
            setdata(prevData => prevData.filter(item => item.Product !== Product));
        })

        .catch(err => {
            console.log(err);
        })
    }

    
    return (
        <div>

            <>
                <div>
                    <br />
                    <center><h3>For Badminton</h3></center>
                    <br />
                <Table striped bordered hover>
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Id</th>
                            <th>Product</th>
                            <th>Price</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            data.map((a,index) => {
                                return (
                                    <tr>
                                        <td>{index+1}</td>
                                        <td>{a.Id}</td>
                                        <td>{a.Product}</td>
                                        <td>{a.Price}</td>
                                        
                                        <td><button
                                        onClick={ ()=>{
                                            handledelete(a.Product)
                                        }}
                                        >delete</button></td>
                                    </tr>
                                )
                            })
                        }
                    </tbody> 
                    </Table>
                </div>
            </>
  <br /><br />
        </div>
    )
}



export default Tableproduct2
