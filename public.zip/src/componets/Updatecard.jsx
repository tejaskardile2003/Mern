import React from 'react';
import { Col, Button, Row, Container, Card, Form } from 'react-bootstrap';
import {Link} from 'react-router-dom'
import axios from 'axios';
import { useState,useEffect } from 'react';
function Updatecard() {

  const xyz = localStorage.getItem('Id'); 
  const [validated, setValidated] = useState(false);
 
  const [Id,setid]=useState()
  const [Product,setproduct]=useState("")
  const [Price,setprice]=useState("")

                   
  const handleSubmit = (e) => {
    
    const setdata={
      Id:Id,
      Product:Product,
      Price:Price
    }

    axios.put(`http://localhost:8000/abc/update/${xyz}`,setdata)
    .then(res=>
        {
            console.log(res.data)
        })
    .catch((err)=>
    {
        console.log();
    })


    setValidated(true);
  };

  useEffect(() => {
    axios.get(`http://localhost:8000/abc/findcard/${xyz}`)
        .then(res => {
            console.log(res.data);
            const setdata= res.data.data
            setid(setdata.Id)
            setproduct(setdata.Product)
            setprice(setdata.Price)
        })

        .catch(err => {
            console.log(err);
        })
}, [])

  return (
    <div>
        <br /><br /><br />
      <Container>
        <Row className="vh-100 d-flex justify-content-center align-items-center">
        {/* <Form > */}
          <Col md={8} lg={6} xs={12}>
            <Card className="px-4">
              <Card.Body>
                <div className="mb-3 mt-md-4">
                  
                  <br></br>
                  <div className="mb-3">
                    <Form noValidate validated={validated} onSubmit={handleSubmit}>
                      <Form.Group className="mb-3" controlId="Name">
                        <Form.Label className="text-center">Id</Form.Label>
                        <Form.Select defaultValue="Choose..." type="text"
                         value={Id}
                         onChange={(e)=>setid(e.target.value)}>
                          <option>Select Id</option>
                          <option>Cricket</option>
                          <option>Badminton</option>
                          <option>Football</option>
                        
                        </Form.Select>
                        {/* <Form.Control type="text" placeholder="Enter Name" 
                        value={Id}
                        onChange={(e)=>setid(e.target.value)}/> */}
                      </Form.Group>

                      <Form.Group className="mb-3" controlId="formBasicEmail">
                        <Form.Label className="text-center">
                          Product
                        </Form.Label>
                        <Form.Control type="text" placeholder="Enter product" 
                        value={Product}
                        onChange={(e)=>setproduct(e.target.value)}/>
                      </Form.Group>

                      <Form.Group className="mb-3" controlId="formBasicPassword">
                        <Form.Label>Price</Form.Label>
                        <Form.Control type="Number" placeholder="Enter price" 
                        value={Price}
                        onChange={(e)=>setprice(e.target.value)}/>
                      </Form.Group>

                      {/* <Form.Group className="mb-3" controlId="formBasicUsername" >
                        <Form.Label> Password</Form.Label>
                        <Form.Control type="password" placeholder="Enter password"
                         value={Password}
                         onChange={(e)=>setPassword(e.target.value)} />
                      </Form.Group>

                        <Form.Group className="mb-3" controlId="formBasicPho">
                        <Form.Label className="text-center">
                         PhoneNo
                        </Form.Label>
                        <Form.Control type="tel" placeholder="Enter phoneno." 
                        value={PhoneNo}
                        onChange={(e)=>setPhoneNo(e.target.value)}/>
                      </Form.Group>


                     <Form.Group className="mb-3" controlId="formBasicEmail">
                        <Form.Label className="text-center">
                           Address
                        </Form.Label>
                        <Form.Control type="text-area" placeholder="Enter Address"
                        value={Address}
                        onChange={(e)=>setAddress(e.target.value)} />
                      </Form.Group> */}

                      <br></br>
                      {/* <div className="d-grid"> */}
                        <Button variant="primary" type="submit">
                          Submit
                        </Button>
                      {/* </div> */}
                    </Form>
                    {/* <div className="mt-3">
                      <p className="mb-0  text-center"> Already have an account??&nbsp;<Link to="/login" ><button variant="primary" style={{backgroundColor:"#2F58CD", color:"white"}}>Login</button></Link>  </p>
                       
             
                     
                    </div> */}
                  </div>
                </div>
              </Card.Body>
            </Card>
          </Col>
          
        </Row>
      </Container>
    </div>
  );
}
export  default Updatecard;