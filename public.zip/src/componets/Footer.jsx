import React from 'react';
import Container from 'react-bootstrap/esm/Container';
import pic1 from './images/facebook.jpg';
import pic2 from './images/what.png';
import pic3 from './images/instagram.jpg';
const Footer = () => {
  return (
    <div>
      <Container>
    <footer className="footer">
      <div className="container">
      <br></br>
      <br></br>
        <table className='table table-dark'>
          <tr>
           
        <div className="row">
       
            
          <div className="col-md-4">
          <br></br>
            <h4>Impoertant links</h4>
            <ul>
              <li><a href="/" style={{ color:"white"} }>Home</a></li>
              <li><a href="/about" style={{ color:"white"} }>About</a></li>
              <li><a href="/contact" style={{ color:"white"} }>Contact</a></li>
            </ul>
          </div>
          <div className="col-md-4">
          <br></br>
            <h4>Contact Us</h4>
            <p>Email: shiramshop@gmail.com</p>
            <p>Phone: (123) 456-7890</p>
          </div>
          <div className="col-md-4">
          <br></br>
          
            <h4>Follow Us</h4>
            
              <img src={pic1} alt="" width={"8%"} />&nbsp;&nbsp;
              <img src={pic2} alt="" width={"8%"}/>&nbsp;&nbsp;
              {/* <li><a href="#action3">Instagram</a></li> */}
              <img src={pic3} alt=""width={"8%"} />
          
          </div>
          <marquee behavior="" direction="" >Shiram Sports Shop, Ahmednagar</marquee>
        </div>
        </tr>
        </table>
      </div>
      <div className="footer-bottom">
        <center><p>&copy; 2023 Shiram Shop. All Rights Reserved.</p></center>
      </div>
      
    </footer>
    </Container>
    </div>
  );
};

export default Footer;