import React from 'react';
import Container from 'react-bootstrap/esm/Container';
import pic1 from './images/facebook.jpg';
import pic2 from './images/what.png';
import pic3 from './images/instagram.jpg';
import pic4 from './images/gmap.jpg';
const Footer = () => {
  return (
    <div>

    <footer className="footer" >
        <div style={{backgroundColor:"black"}}>
      <div className="container" >
      <br></br>
      <br></br>
        {/* <table className='table table-dark'>
          <tr> */}
           
        <div className="row" style={{color:"white"}}>
       
            
          <div className="col-md-3">
          <br></br>
            <h4>Impoertant links</h4>
            <ul>
              <li><a href="/" style={{ color:"white"} }>Home</a></li>
              <li><a href="/about" style={{ color:"white"} }>About</a></li>
              <li><a href="/contact" style={{ color:"white"} }>Contact</a></li>
            </ul>
          </div>
          <div className="col-md-3">
          <br></br>
            <h4>Contact Us</h4>
            <p>Email: <a href="mailto:aglawenikhil56@gmail.com" style={{textDecoration: 'none'}}>aglawenikhil56@gmail.com</a></p>
            <p>Phone: <a href="tel:+8788747059" style={{textDecoration: 'none'}}>8788747059</a></p>
          </div>
          <div className="col-md-3">
          <br></br>
          
            <h4>Follow Us</h4>
            
              <img src={pic1} alt="" width={"8%"} />&nbsp;&nbsp;
              <img src={pic2} alt="" width={"8%"}/>&nbsp;&nbsp;
              {/* <li><a href="#action3">Instagram</a></li> */}
              <img src={pic3} alt=""width={"8%"} />
          
          </div>
          <div className="col-md-3">
          <br></br>
          
            <h4>Shop Address</h4>
            
             <p>National Highway No.50 Govind Nagar Near Bank of India ATM, Ahmednagar, Maharashtra 422605</p>
             <img src={pic4} alt="" width={"8%"}/><a href="https://maps.app.goo.gl/juLSa8EYzWAPQ2QH8" style={{textDecoration: 'none'}}>&nbsp;&nbsp;<i style={{fontSize:"18px"}}>https://maps.app.goo.gl</i></a>
          </div>
          <marquee behavior="" direction="" >Sportplus Shop, Ahmednagar</marquee> 
        </div>
        {/* </tr>
        </table> */}
        <br></br>
        </div>
      </div>
      
      <div className="footer-bottom">
      <br></br>
        <center><p>&copy; 2023 Sportplus Shop.Designed by Team Dhruva.</p></center>
        <br></br>
      </div>
      
    </footer>
    </div>
  );
};

export default Footer;