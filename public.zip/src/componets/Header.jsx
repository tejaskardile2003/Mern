import Button from 'react-bootstrap/Button';
import Container from 'react-bootstrap/Container';
import Form from 'react-bootstrap/Form';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import {Link} from 'react-router-dom';
function Header() {
  return (
    <Navbar expand="lg" className="bg-body-tertiary">
      <Container fluid>
        <Navbar.Brand href="#">Shiram Shop</Navbar.Brand>
        <Navbar.Toggle aria-controls="navbarScroll" />
        <Navbar.Collapse id="navbarScroll">
          <Nav
            className="me-auto my-2 my-lg-0"
            style={{ maxHeight: '100px' }}
            navbarScroll
          >
            {/* <Nav.Link to="/home">Home</Nav.Link>
            <Nav.Link to="/about">Abouts</Nav.Link>
            <NavDropdown title="Login/Registration" id="navbarScrollingDropdown">
              <NavDropdown.Item href="#action3">Registration</NavDropdown.Item>
              <NavDropdown.Item href="#action4">
                Login
              </NavDropdown.Item>
              <NavDropdown.Divider />
              <NavDropdown.Item href="#action5">
                Something else here
              </NavDropdown.Item>
            </NavDropdown>
            <Nav.Link href="#" >
              Link
            </Nav.Link> */}

            <Link to="/home" style={{padding:"10px", color:"black"} }>Home</Link>
            <Link to="/about" style={{padding:"10px" ,color:"black"}}>About</Link>
            <Link to="/team" style={{padding:"10px" ,color:"black"}}>Team</Link>
            <Link to="/contact" style={{padding:"10px", color:"black"}}>Contact</Link>
            <NavDropdown title="Login/Registration" id="navbarScrollingDropdown" style={{ paddingTop:"5px"}}>
            <NavDropdown.Item>
            <Link to="/register" style={{padding:"10px" ,color:"black"}}>Registration</Link>
            </NavDropdown.Item>
              <NavDropdown.Item href="#action4">
              <Link to="/login" style={{padding:"10px" ,color:"black"}}>Login</Link>
              </NavDropdown.Item>
              <NavDropdown.Divider />
              </NavDropdown>
          </Nav>
          <Form className="d-flex">
            <Form.Control
              type="search"
              placeholder="Search"
              className="me-2"
              aria-label="Search"
            />
            <Button variant="outline-success">Search</Button>
          </Form>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

export default Header;