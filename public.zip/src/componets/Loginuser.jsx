import React from 'react';
import { Col, Button, Row, Container, Card, Form } from 'react-bootstrap';
import {Link} from 'react-router-dom'
import axios from 'axios';
import { useState } from 'react';
function LoginPage() {
  const [validated, setValidated] = useState(false);
 
  
  const[Username,setUsername]=useState("");
  const[Password,setPassword]=useState("");

  const handleSubmit = (event) => {
  
    const setdata={
      Username:Username,
      Password: Password,
    }
    axios.post("http://localhost:8000/abc/user",setdata)
    .then(res=>
        {
            console.log(res.data)
        })
    .catch((err)=>
    {
        console.log();
    })

    setValidated(true);
  };

  
  return (
    <div>
      
      <Container>
        <Row className="vh-100 d-flex justify-content-center align-items-center">
          <Col md={8} lg={6} xs={12}>
            <Card className="px-4">
              <Card.Body>
                <div className="mb-3 mt-md-4">
                  <h3 className=" mb-2 text-center text-uppercase ">
                    User Login
                  </h3>
                  <br></br>
                  <div className="mb-3">
                    <Form noValidate validated={validated} onSubmit={handleSubmit}>
                 <Form.Group className="mb-3" controlId="formBasicPassword">
                        <Form.Label>Username</Form.Label>
                        <Form.Control type="text" placeholder="Enter username" 
                        value={Username}
                        onChange={(e)=>setUsername(e.target.value)}/>
                      </Form.Group>

                      <Form.Group className="mb-3" controlId="formBasicUsername" >
                        <Form.Label> Password</Form.Label>
                        <Form.Control type="password" placeholder="Enter password"
                         value={Password}
                         onChange={(e)=>setPassword(e.target.value)} />
                      </Form.Group>

                      


                    

                      <br></br>
                      <div className="d-grid">
                      <Link to="account"><Button variant="primary" type="submit">
                          Login
                        </Button></Link>

                        {/* <Link to="/account"> <Button variant="primary" type="submit">
                          Your Account
                        </Button></Link> */}
                      </div>
                    </Form>
                    
                  </div>
                </div>
              </Card.Body>
            </Card>
          </Col>
          
        </Row>
      </Container>
      <br /><br /><br /><br /><br /><br /><br /><br />
    </div>
  );
}
export  default LoginPage;