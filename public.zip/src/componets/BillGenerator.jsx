import React from 'react';
import styled from 'styled-components';
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';


const Table = styled.table`
  width: 100%;
  border-collapse: collapse;
  margin-bottom: 1em;
`;

const Th = styled.th`
  background-color: #f2f2f2;
  text-align: center;
`;

const Td = styled.td`
  padding: 8px;
  border: 1px solid #ddd;
  text-align: center;
`;

const BillGenerator = ({ products }) => {
  const getDate = () => {
    const today = new Date();
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return today.toLocaleDateString(undefined, options);
  };

  const calculateTotalCost = () => {
    return products.reduce((total, product) => {
      return total + product.Noitem * product.Price;
    }, 0);
  };

  const cardHeight = 500 + products.length * 50;
  return (
    <div>
      <center>
        <Card style={{ width: '700px', height: cardHeight, border: '1px solid', padding: '0px 20px 0 20px' }}>
          <br /><br />
          <p style={{textAlign:'left'}}>Date: {getDate()}</p>
          <h3 style={{textAlign:'left'}}>Receipt</h3>
          <Card.Body>
            <Card.Title>
             
              
            </Card.Title>
            <Card.Text>
              <Table border={2}>
                <thead>
                  <tr>
                    <Th><h4>Product</h4></Th>
                    <Th><h4>Quantity</h4></Th>
                    <Th><h4>Price</h4></Th>
                     <Th><h4>Total</h4></Th>
                  </tr>
                </thead>
                <tbody>
                  {products.map((product, index) => (
                    <tr key={index}>
                      <Td>{product.Product}</Td>
                      <Td>{product.Noitem}</Td>
                      <Td>{product.Price.toFixed(2)}<h6>Rs</h6></Td>
                      <Td>{(product.Noitem * product.Price).toFixed(2)}<h6>Rs</h6></Td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr>
                    <Td colSpan="3"><b><h4>Total Cost:</h4></b></Td>
                    <Td><h6>{calculateTotalCost().toFixed(2)}Rs</h6></Td>
                  </tr>
                </tfoot>
              </Table>
            </Card.Text>
            <br /><br />
            <Button variant="primary">Place Order</Button>
          </Card.Body>
        </Card>
      </center>
      <br /><br /><br />
    </div>
  );
};

export default BillGenerator;