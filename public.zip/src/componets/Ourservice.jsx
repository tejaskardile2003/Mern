import React from 'react'
import { Container } from 'react-bootstrap'
import image3 from './images/refundreplace.png'
import image1 from './images/shipping.jpg'
import image2 from './images/secure.png'
 import image4 from './images/g.png'
const Ourservice = () => {
  return (
    <div >
         <br></br>
         <br></br>
         <br></br>
       
    <div className='ourservice'>
    <br></br>
   <Container>
       <div className="row">
       
            
        <div className="col-md-3">
        <br></br>
           <h5 > <img src={image1} alt="" width={"15%"} /> Easy Shipping</h5>
             
        </div>
        <div className="col-md-3">
        <br></br>
        <h5 > <img src={image2} alt="" width={"15%"} />Secure Payment</h5>
        </div>
        <div className="col-md-3">
        <br></br>
        <h5> <img src={image3} alt="" width={"16%"} />7 days refund/replacement</h5>
        
        </div>
        <div className="col-md-3">
        <br></br>
        <h5> <img src={image4} alt="" width={"15%"} />100% Gurantee</h5>
            
        </div>
       
     </div>
     </Container>
     <br></br>
     </div>
     </div>
  )
}

export default Ourservice
