
import Container from 'react-bootstrap/Container';
import Product1 from './images/imag1.jpeg';
import Card from 'react-bootstrap/Card';
import React from "react";
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Button from 'react-bootstrap/Button';
const Map = () => {

    const abc=[

        {
            id:1,
            title:"Sport",
            descripation:"Some quick example text to build on the card title and make up the bulk of the card's content."
        },

        {
            id:2,
            title:"Sport",
            descripation:"Some quick example text to build on the card title and make up the bulk of the card's content."
        },

        {
            id:3,
            title:"Sport",
            descripation:"Some quick example text to build on the card title and make up the bulk of the card's content."
        },

        {
            id:4,
            title:"Sport",
            descripation:"Some quick example text to build on the card title and make up the bulk of the card's content."
        },

        {
            id:5,
            title:"Sport",
            descripation:"Some quick example text to build on the card title and make up the bulk of the card's content."
        },

        {
            id:6,
            title:"Sport",
            descripation:"Some quick example text to build on the card title and make up the bulk of the card's content."
        }

        
    ]

  return (
    <div>
        <Container>
          <Row>
      {
        abc.map((a)=>{
            return(
                    <>
                        <Col md={3}>
                            <Card >
                                <Card.Img variant="top" src={Product1} />
                                <Card.Body>
                                  <Card.Title>{a.title}</Card.Title>
                                  <Card.Text> {a.descripation}</Card.Text>
                                  <Button variant="dark">Add to cart</Button>
                                </Card.Body>
                               
                            </Card>
                          </Col>       
                    </>
                
            )
        })
      }
       </Row>
      </Container>
    </div>
  )
}

export default Map
