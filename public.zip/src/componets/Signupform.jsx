import React, { useState } from 'react';

import axios from 'axios'
import Tableproduct from './Tableproduct';
import Tableproduct2 from './Tableproduct2';
import Tableproduct3 from './Tableproduct3';
const Signupform= () => {
  

  const [Id,setid]=useState()
  const [Product,setproduct]=useState("")
  const [Price,setprice]=useState("")

                   
  const handleSubmit = (e) => {
    
    const setdata={
      Id:Id,
      Product:Product,
      Price:Price
    }
    
    const item1=Id;
    const item2="cricket";
    const item3="football";
    const item4="badminton";



     if (item1===item2) {
      
     
     

    axios.post("http://localhost:8000/abc/addcric",setdata)
    .then(res=>
      {
        console.log(res.data)
     
      })
      .catch((err)=>
      {
        console.log(err);

      })




  };


  if (item1===item3) {
      
     
     

    axios.post("http://localhost:8000/abc/addfoot",setdata)
    .then(res=>
      {
        console.log(res.data)
     
      })
      .catch((err)=>
      {
        console.log(err);

      })




  };

  if (item1===item4) {
      
     
     

    axios.post("http://localhost:8000/abc/addbad",setdata)
    .then(res=>
      {
        console.log(res.data)
     
      })
      .catch((err)=>
      {
        console.log(err);

      })




  };


}

  return (
     <div> 
    <form onSubmit={handleSubmit}style={{margin:"100px",width:'100%'}} >
      <center>

      <h2 style={{margin:'0 0 0 0'}}>Add Items</h2>
      <br />



      <tr>
        <td>
        <label style={{padding:"10px"}}>Id</label>
        </td>

        <td>
        <input type="text" name="Id" value={Id} onChange={(e)=>{ setid(e.target.value)}} />
        </td>
        
      </tr>


      <tr>
       <td>
       <label style={{padding:"10px"}}>Product </label >
       </td>
        <td>
          <input type="text" name="Name" value={Product}  onChange={(e)=>{ setproduct(e.target.value)}} />
        </td>
      </tr>
     

      <tr>
          <td>
          <label style={{padding:"10px"}}> Price </label>
          </td>
          <td>

          <input type="Number" name="Product" value={Price}  onChange={(e)=>{ setprice(e.target.value)}} />
          
          </td>
      </tr>
      
      
    

{/* 
      <tr>
        <td>
        <label style={{padding:"10px"}}>Phone no: </label>
        </td>

        <td>
        <input type="text" name="phone" value={formData.phone} onChange={handleChange} />
        </td>
        
      </tr> 



      <tr>
        <td>
        <label style={{padding:"10px"}}>Email:</label>
        

        </td>

        <td>
        <input type="email" name="email" value={formData.email} onChange={handleChange} />
       </td>
        
      </tr>  */}

      <tr>
        <br />
        {/* <td>
        <label style={{padding:"10px"}}>Address:</label>
        </td> */}
{/* 
        <td>
        <textarea name="address" value={formData.address} onChange={handleChange}></textarea>
        </td> */}
        
      </tr> 




      <tr>
        <td colSpan={2}>
        <button type="submit" style={{color:'blue'}}>Add product</button>

        </td>

        
      </tr>

      </center>
        
    </form>
      <Tableproduct/>
      <Tableproduct3/>
      <Tableproduct2/>
    </div>
  );
};

export default Signupform;
