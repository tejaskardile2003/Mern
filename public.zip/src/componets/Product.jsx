import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';
import React from "react";
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Container from 'react-bootstrap/Container';
import 'bootstrap/dist/css/bootstrap.min.css';
import Product1 from './images/imag1.jpeg';
import Product2 from './images/imag2.jpg';
import Product3 from './images/imag3.jpeg';
import Product4 from './images/imag4.jpg';
import Product5 from './images/imag5.jpg';
import Product6 from './images/imag6.jpg';
import Product7 from './images/imag7.jpg';
import Product8 from './images/imag8.jpg';
import Product9 from './images/imag9.jpg';
import Product10 from './images/imag10.jpg';
import Product11 from './images/imag11.jpg';
import Product12 from './images/imag12.jpg';
import Product13 from './images/imag13.jpg';
import Product14 from './images/imag14.jpg';
import Product15 from './images/imag15.jpg';
import Product16 from './images/imag16.jpg';
import Product17 from './images/imag17.jpg';
import Product18 from './images/imag18.jpg';
import Product19 from './images/imag19.jpg';
import Product20 from './images/imag20.jpg';
import Product21 from './images/imag21.jpg';
import Product22 from './images/imag22.jpeg';
import Product23 from './images/imag23.jpg';
import Product24 from './images/imag24.jpg';
import Product25 from './images/imag25.jpg';
import Product26 from './images/imag26.jpg';
import Product27 from './images/imag27.jpg';
import Product28 from './images/imag28.jpg';
function More() {
  return (
  
    <Container>
    <br></br>
    <br></br>
    <Row>
    <Col md={3}>
      <Card >
        <Card.Img variant="top" src={Product28} />
        <Card.Body>
          <Card.Title>Baseball Gloves</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
          <Button variant="dark">Add to cart</Button>
        </Card.Body>
      </Card>
      </Col>

      <Col md={3}>
      <Card >
        <Card.Img variant="top" src={Product27} />
        <Card.Body>
          <Card.Title>BaseBall</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
          <Button variant="dark">Add to cart</Button>
        </Card.Body>
      </Card>
      </Col>

      <Col md={3}>
      <Card >
        <Card.Img variant="top" src={Product26} />
        <Card.Body>
          <Card.Title>Baseball Bat</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
          <Button variant="dark">Add to cart</Button>
        </Card.Body>
      </Card>
      </Col>

      <Col md={3}>
      <Card >
        <Card.Img variant="top" src={Product25} />
        <Card.Body>
          <Card.Title>FootBall Gloves</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
          <Button variant="dark">Add to cart</Button>
        </Card.Body>
      </Card>
      </Col>
    </Row>
    
    <br></br>
    <br></br>
    <Row>
    <Col md={3}>
      <Card >
        <Card.Img variant="top" src={Product24} />
        <Card.Body>
          <Card.Title>Football Shoes</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
          <Button variant="dark">Add to cart</Button>
        </Card.Body>
      </Card>
      </Col>

      <Col md={3}>
      <Card >
        <Card.Img variant="top" src={Product6} />
        <Card.Body>
          <Card.Title>Rugby</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
          <Button variant="dark">Add to cart</Button>
        </Card.Body>
      </Card>
      </Col>

      <Col md={3}>
      <Card >
        <Card.Img variant="top" src={Product23} />
        <Card.Body>
          <Card.Title>Football Net</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
          <Button variant="dark">Add to cart</Button>
        </Card.Body>
      </Card>
      </Col>

      <Col md={3}>
      <Card >
        <Card.Img variant="top" src={Product8} />
        <Card.Body>
          <Card.Title>Rope Skipping</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
          <Button variant="dark">Add to cart</Button>
        </Card.Body>
      </Card>
      </Col>
    </Row>
    
   <br></br>
    <br></br>

    <Row>
    <Col md={3}>
      <Card >
        <Card.Img variant="top" src={Product22} />
        <Card.Body>
          <Card.Title>Basketball Hoop</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
          <Button variant="dark">Add to cart</Button>
        </Card.Body>
      </Card>
      </Col>

      <Col md={3}>
      <Card >
        <Card.Img variant="top" src={Product21} />
        <Card.Body>
          <Card.Title>Badminton String</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
          <Button variant="dark">Add to cart</Button>
        </Card.Body>
      </Card>
      </Col>

      <Col md={3}>
      <Card >
        <Card.Img variant="top" src={Product20} />
        <Card.Body>
          <Card.Title>Grip</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
          <Button variant="dark">Add to cart</Button>
        </Card.Body>
      </Card>
      </Col>

      <Col md={3}>
      <Card >
        <Card.Img variant="top" src={Product13} />
        <Card.Body>
          <Card.Title>Helmet</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
          <Button variant="dark">Add to cart</Button>
        </Card.Body>
      </Card>
      </Col>
    </Row>
     
    <br></br>
    <br></br>

    <Row>
    <Col md={3}>
      <Card >
        <Card.Img variant="top" src={Product19} />
        <Card.Body>
          <Card.Title>Badminton Net</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
          <Button variant="dark">Add to cart</Button>
        </Card.Body>
      </Card>
      </Col>

      <Col md={3}>
      <Card >
        <Card.Img variant="top" src={Product14} />
        <Card.Body>
          <Card.Title>Wicket Balls</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
          <Button variant="dark">Add to cart</Button>
        </Card.Body>
      </Card>
      </Col>

      <Col md={3}>
      <Card >
        <Card.Img variant="top" src={Product18} />
        <Card.Body>
          <Card.Title>Cricket Bag</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
          <Button variant="dark">Add to cart</Button>
        </Card.Body>
      </Card>
      </Col>

      <Col md={3}>
      <Card >
        <Card.Img variant="top" src={Product15} />
        <Card.Body>
          <Card.Title>Test Ball</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
          <Button variant="dark">Add to cart</Button>
        </Card.Body>
      </Card>
      </Col>
    </Row>

    <br></br>
    <br></br>

    <Row>
    <Col md={3}>
      <Card >
        <Card.Img variant="top" src={Product9} />
        <Card.Body>
          <Card.Title>Stumps</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
          <Button variant="dark">Add to cart</Button>
        </Card.Body>
      </Card>
      </Col>

      <Col md={3}>
      <Card >
        <Card.Img variant="top" src={Product10} />
        <Card.Body>
          <Card.Title>Tabletennis Racket</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
          <Button variant="dark">Add to cart</Button>
        </Card.Body>
      </Card>
      </Col>

      <Col md={3}>
      <Card >
        <Card.Img variant="top" src={Product16} />
        <Card.Body>
          <Card.Title>Tennis Ball</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
          <Button variant="dark">Add to cart</Button>
        </Card.Body>
      </Card>
      </Col>

      <Col md={3}>
      <Card >
        <Card.Img variant="top" src={Product17} />
        <Card.Body>
          <Card.Title>Cricket Shoes</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
          <Button variant="dark">Add to cart</Button>
        </Card.Body>
      </Card>
      </Col>
    </Row>

    <br></br>
    <br></br>

    <Row>
    <Col md={3}>
      <Card >
        <Card.Img variant="top" src={Product1} />
        <Card.Body>
          <Card.Title>Badminton</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
          <Button variant="dark">Add to cart</Button>
        </Card.Body>
      </Card>
      </Col>

      <Col md={3}>
      <Card >
        <Card.Img variant="top" src={Product11} />
        <Card.Body>
          <Card.Title>Volly Ball</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
          <Button variant="dark">Add to cart</Button>
        </Card.Body>
      </Card>
      </Col>

      <Col md={3}>
      <Card >
        <Card.Img variant="top" src={Product4} />
        <Card.Body>
          <Card.Title>Bat</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
          <Button variant="dark">Add to cart</Button>
        </Card.Body>
      </Card>
      </Col>

      <Col md={3}>
      <Card >
        <Card.Img variant="top" src={Product12} />
        <Card.Body>
          <Card.Title>Pad</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
          <Button variant="dark">Add to cart</Button>
        </Card.Body>
      </Card>
      </Col>
    </Row>

    <br></br>
    <br></br>

    <Row>
    <Col md={3}>
      <Card >
        <Card.Img variant="top" src={Product2} />
        <Card.Body>
          <Card.Title>Ball</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
          <Button variant="dark">Add to cart</Button>
        </Card.Body>
      </Card>
      </Col>

      <Col md={3}>
      <Card >
        <Card.Img variant="top" src={Product3} />
        <Card.Body>
          <Card.Title>Basketball</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
          <Button variant="dark">Add to cart</Button>
        </Card.Body>
      </Card>
      </Col>

      <Col md={3}>
      <Card >
        <Card.Img variant="top" src={Product5} />
        <Card.Body>
          <Card.Title>Gloves</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
          <Button variant="dark">Add to cart</Button>
        </Card.Body>
      </Card>
      </Col>

      <Col md={3}>
      <Card >
        <Card.Img variant="top" src={Product7} />
        <Card.Body>
          <Card.Title>Shuttle</Card.Title>
            <Card.Text>
              Some quick example text to build on the card title and make up the
              bulk of the card's content.
            </Card.Text>
          <Button variant="dark">Add to cart</Button>
        </Card.Body>
      </Card>
      </Col>
    </Row>


    
    </Container>
  );
}

export default More;

