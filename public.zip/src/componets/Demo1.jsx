import React, { useState } from 'react'

const Demo1 = () => {

    const [text,settext]=useState("Welcome")
    const [text1,settext1]=useState("")
  return (
    <div>
        <center>
        <br></br>
        <h1 style={{color:"red"}}>{text1}</h1>
        <br></br>
        <br></br>
        
        
        <input type="text" value={text1} />
        <br></br>
        <br></br>
        <input type="text"  value={text} onChange={(e)=>{settext(e.target.value)}} />
        <button onClick={()=>{settext1(text)}}>ChangeText</button>
      
      </center>
    </div>
  )

  
}

export default Demo1
