import React from 'react';
import styled from 'styled-components';
import BillGenerator from './BillGenerator';
import { useState } from 'react';
import axios from 'axios';
import {useEffect } from 'react';


const Table = styled.table`
  width: 100%;
  border-collapse: collapse;
  margin-bottom: 1em;
`;

const Th = styled.th`
  background-color: #f2f2f2;
  text-align: center;
`;

const Td = styled.td`
  padding: 8px;
  border: 1px solid #ddd;
  text-align: center;
`;

const RemoveButton = styled.button`
  background-color: #007BFF;
  color: #fff;
  padding: 5px 10px;
  cursor: pointer;
`;

const ShowBillButton = styled.button`
  background-color: #007BFF;
  color: #fff;
  padding: 10px;
  cursor: pointer;
  display: block;
  margin: 0 auto;
`;

const Shopcart = () => {
    const [showBill, setShowBill] = useState(false);
  const handleRemove = (index) => {
    handleRemoveItem(index);
  };

  const[data,setdata]=useState([]);
  

  useEffect(() => {
    axios.get("http://localhost:8000/abc/shopcart")
        .then(res => {
            console.log(res.data);
            setdata(res.data.userdata);
        })
        .catch(err => {
            console.log(err);
        });
}, []);
  


  const handleRemoveItem = (index) => {
    const removedProduct = data[index];

  // Make an HTTP request to remove the product from the database
  

      // If the server successfully removes the product, update the client-side state
      const updatedCartItems = data.filter((_, i) => i !== index);
      setdata(updatedCartItems);
      axios.delete(`http://localhost:8000/abc/del/${removedProduct.Id}`)
    .then(res => {
      console.log(res.data);
    })
    .catch(err => {
      console.log(err);
    });
  };
  return (
    <>
      <br /><br />
      <center><h3>Your Cart</h3></center>

      <h4 style={{ padding: "10px 0 5px 40px" }}>Product List</h4>
      <Table>
        <thead>
          <tr>
            <Th><h4>Product</h4></Th>
            <Th><h4>Price</h4></Th>
            <Th><h4>Quantity</h4></Th>
            <Th><h4>Remove</h4></Th>
          </tr>
        </thead>
        <tbody>
          {data.map((item, index) => (
            <tr key={index}>
              <Td>{item.Product}</Td>
              <Td>{item.Price}</Td>
              <Td>{item.Noitem}</Td>
              <Td>
                <RemoveButton onClick={() => handleRemove(index)}>
                  Remove
                </RemoveButton>
              </Td>
            </tr>
          ))}
        </tbody>
        <br /><br />
      </Table>
      <ShowBillButton onClick={() => setShowBill(!showBill)}>
        {showBill ? 'Hide Bill' : 'Generate Bill'}
      </ShowBillButton>
      <br />

      {showBill && (
        <div>
          <BillGenerator products={data} />
        </div>
      )}
    </>
  );
};

export default Shopcart;