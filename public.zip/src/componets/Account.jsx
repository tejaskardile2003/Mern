import axios from 'axios';
import  { useEffect, useState } from 'react';
import Button from 'react-bootstrap/Button';
import Col from 'react-bootstrap/Col';
import Form from 'react-bootstrap/Form';
import InputGroup from 'react-bootstrap/InputGroup';
import Row from 'react-bootstrap/Row';
import {   Container, Card } from 'react-bootstrap';
import pic from './images/acc1.png';
import Addcard from './Addcard'
import {Link} from 'react-router-dom';
function Account() {
  
  const [validated, setValidated] = useState(false);
 
  const[Name,setName]=useState("");
  const[Email,setEmail]=useState("");
  const[Username,setUsername]=useState("");
  const[PhoneNo,setPhoneNo]=useState();
  const[Address,setAddress]=useState("");
  const handleSubmit = (event) => {
  
    const setdata={
      Name:Name,
      Email:Email,
      Username:Username,
      PhoneNo:PhoneNo,
      Address:Address
    }
    setValidated(true);
    axios.put("http://localhost:8000/abc/update/nik",setdata)
  .then(res=>
      {
          console.log(res.data)
      })
  .catch((err)=>
  {
      console.log();
  })
  };

  
  useEffect(() => {
    axios.get(`http://localhost:8000/abc/finduser/nik`)
        .then(res => {
            console.log(res.data);
            const setdata= res.data.data
            setName(setdata.Name)
            setEmail(setdata.Email)
            setUsername(setdata.Username)
            setPhoneNo(setdata.PhoneNo)
            setAddress(setdata.Address)
        })

        .catch(err => {
            console.log(err);
        })
}, [])

  return (
    <Container>
        <Row className="vh-100 d-flex justify-content-center align-items-center">
        {/* <Form > */}
          <Col md={8} lg={8} xs={12}>
            <Card className="px-6">
              <Card.Body>
                <div className="mb-3 mt-md-4">
                  <center>
                  <img src={pic} alt="" width={"25%"}/>
                  <h4 className=" mb-2  text-uppercase ">
                 
                    My Account
                  </h4>
                  </center>
                  <br></br>
                  
                  <div className="mb-3"></div>
                    <Form noValidate validated={validated} onSubmit={handleSubmit}>
                    <Row className="mb-3">
                        <Form.Group as={Col} md="4" controlId="validationCustom01">
                        <Form.Label>Name</Form.Label>
                        <Form.Control
                            required
                            type="text"
                            placeholder="name"
                            value={Name}
                            onChange={(e)=>setName(e.target.value)}
                            // defaultValue="Mark"
                        />
                        {/* <Form.Control.Feedback>Looks good!</Form.Control.Feedback> */}
                        </Form.Group>
                        <Form.Group as={Col} md="4" controlId="validationCustom02">
                        <Form.Label>Email</Form.Label>
                        <Form.Control
                            required
                            type="text"
                            placeholder="email"
                            value={Email}
                            onChange={(e)=>setEmail(e.target.value)}
                            // defaultValue="Otto"
                        />
                        {/* <Form.Control.Feedback>Looks good!</Form.Control.Feedback> */}
                        </Form.Group>
                        <Form.Group as={Col} md="4" controlId="validationCustomUsername">
                        <Form.Label>Username</Form.Label>
                            <Form.Control
                            type="text"
                            placeholder="Username"
                            required
                            value={Username}
                            onChange={(e)=>setUsername(e.target.value)}
                            />
                            {/* <Form.Control.Feedback type="invalid">
                            Please choose a username.
                            </Form.Control.Feedback> */}
                        
                        </Form.Group>
                    </Row>
                    <Row className="mb-3">
                        <Form.Group as={Col} md="5" controlId="validationCustom03">
                        <Form.Label>Address</Form.Label>
                        <Form.Control type="text" placeholder="address" required 
                            value={Address}
                            onChange={(e)=>setAddress(e.target.value)}/>
                        {/* <Form.Control.Feedback type="invalid">
                            Please provide a valid city.
                        </Form.Control.Feedback> */}
                        </Form.Group>

                        <Form.Group as={Col} md="3" controlId="validationCustom04">
                        <Form.Label>PhoneNo</Form.Label>
                        <Form.Control type="text" placeholder="phoneno" required 
                            value={PhoneNo}
                            onChange={(e)=>setPhoneNo(e.target.value)}/>
                        {/* <Form.Control.Feedback type="invalid">
                            Please provide a valid state.
                        </Form.Control.Feedback> */}
                        </Form.Group>
                    </Row>
                    {/* <Form.Group className="mb-3">
                        <Form.Check
                        required
                        label="Agree to terms and conditions"
                        feedback="You must agree before submitting."
                        feedbackType="invalid"
                        />
                    </Form.Group> */}
                    <br />
                    <Button type="Submit">Save Edit</Button>
                 
                    </Form>

               </div>
        
        </Card.Body>
    </Card>
    </Col>
 </Row>
</Container>

  );
}

export default Account;
