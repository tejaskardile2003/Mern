import React, { useEffect, useState } from 'react'
import axios from 'axios'
import Container from 'react-bootstrap/Container';
import Product1 from './images/imag1.jpeg';
import Card from 'react-bootstrap/Card';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Button from 'react-bootstrap/Button';
import Table from 'react-bootstrap/Table';
const Deatils = () => {


    const [data, setdata] = useState([])

    useEffect(() => {
        axios.get("http://localhost:8000/abc/findall")
            .then(res => {
                console.log(res.data);
                setdata(res.data.userdata)
            })

            .catch(err => {
                console.log(err);
            })
    }, [])

    return (
        <div>

            <>
                <div>
                <Table striped bordered hover>
                        <tr>
                            <th>Fisratname</th>
                            <th>Lastname</th>
                            <th>Email</th>
                        </tr>
                        {
                            data.map((a) => {
                                return (
                                    <tr>
                                        <td>{a.fname}</td>
                                        <td>{a.lname}</td>
                                        <td>{a.email}</td>
                                        <td><button>update</button></td>
                                        <td><button>delete</button></td>
                                    </tr>
                                )
                            })
                        }
                        
                    </Table>
                </div>
            </>

        </div>
    )
}



export default Deatils
