import React from 'react'
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';
import Product9 from './images/user.png';
import pic2 from './images/basket.jpeg';
const Team = () => {
  return (
    <div>
      
      <Container>
      <br></br>
      <br></br>
        <center><h1>Our Teams</h1></center>
        <br></br>
      <br></br>
      
      
      <Row>
        <Col md={3}>
        <Card >
          <Card.Img variant="top" src={Product9} />
          <Card.Body>
            <center>
            <Card.Title>ABCD</Card.Title>
              <Card.Text className='title'>
              Some quick example text to build on the card title and make up the
                bulk of the card's content.
              </Card.Text>
            <Button variant="dark">Employee 1</Button>
            </center>
          </Card.Body>
        </Card>
        </Col>

        <Col md={3}>
        <Card >
          <Card.Img variant="top" src={Product9} />
          <Card.Body>
          <center>
            <Card.Title>EFGH</Card.Title>
              <Card.Text className='title'>
              Some quick example text to build on the card title and make up the
                bulk of the card's content.
              </Card.Text>
            <Button variant="dark">Employee 2</Button>
            </center>
          </Card.Body>
        </Card>
        </Col>

        <Col md={3}>
        <Card >
          <Card.Img variant="top" src={Product9} />
          <Card.Body>
          <center>
            <Card.Title>IJKL</Card.Title>
              <Card.Text className='title'>
              Some quick example text to build on the card title and make up the
                bulk of the card's content.
              </Card.Text>
            <Button variant="dark">Employee 3</Button>
            </center>
          </Card.Body>
        </Card>
        </Col>

        <Col md={3}>
        <Card >
          <Card.Img variant="top" src={Product9} />
          <Card.Body>
          <center>
            <Card.Title>MNOP</Card.Title>
              <Card.Text className='title'>
              Some quick example text to build on the card title and make up the
                bulk of the card's content.
              </Card.Text>
            <Button variant="dark">Employee 4</Button>
            </center>
          </Card.Body>
        </Card>
        </Col>
      </Row>
    </Container>
    </div>
  )
}

export default Team
