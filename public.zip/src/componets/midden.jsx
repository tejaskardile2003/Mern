import Card from 'react-bootstrap/Card';
import '../App.css';

function TextExample(prop) {
  return (
    <Card style={{ width: '100%', backgroundColor:'#2673B8', textAlign:'center'}} className="fo">
    
      <Card.Body>
        <div >

        <div>
            
        <Card.Title style={{ color:'white', fontSize:'40px'}}>{prop.name}</Card.Title>
        
        {/* <Card.Subtitle  className="mb-2 text-muted" style={{ color:'white'}}>Tree Saplings</Card.Subtitle>
        <Card.Text style={{ color:'gray'}}>
         card title and make up the
          bulk of the card's content.
        </Card.Text> */}
        
        </div>
       

        {/* <div >
        
        <Card.Link href="#">Home</Card.Link>
        <Card.Link href="#">About Us</Card.Link>
        </div> */}

        </div>

      </Card.Body>
      
    </Card>
  );
}

export default TextExample;