import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown'
import Product1 from './images/cart.jpg';
import Product2 from './images/account.jpg';
import {Link} from 'react-router-dom';
function Head() {

    
  return (
    <div className='header'>
       <Navbar fixed="top" />
    <Navbar collapseOnSelect expand="lg" style={{backgroundColor:"#5FBDFF"}} >
      
        <br /> <br />
        <Navbar.Brand href="#home" style={{color:"black" ,fontFamily:"Gill Sans MT",paddingLeft:"15px"}}><h3>Sportplus</h3></Navbar.Brand>
        <Navbar.Toggle aria-controls="responsive-navbar-nav" />
        <Navbar.Collapse id="responsive-navbar-nav">
          <Nav className="me-auto">
          <Link to="/home" style={{padding:"15px", color:"black" ,textDecoration: 'none',fontFamily:"sans-serif"} }>Home</Link>
          <Link to="/services" style={{padding:"15px", color:"black" ,textDecoration: 'none',fontFamily:"sans-serif"} }>Services</Link>
            <NavDropdown title="Sport Categories" id="collapsible-nav-dropdown" style={{paddingTop:"7px",fontFamily:"sans-serif" }}>
              <NavDropdown.Item href="#action/3.1">Cricket</NavDropdown.Item>
              <NavDropdown.Item href="#action/3.2">
                BasketBall
              </NavDropdown.Item>
              <NavDropdown.Item href="#action/3.3">Badminton</NavDropdown.Item>
              <NavDropdown.Item href="#action/3.3">VollyBall</NavDropdown.Item>
              <NavDropdown.Item href="#action/3.3">Tennis</NavDropdown.Item>
              <NavDropdown.Item href="#action/3.3">FootBall</NavDropdown.Item>
              <NavDropdown.Item href="#action/3.3">Carrom</NavDropdown.Item>
              <NavDropdown.Item href="#action/3.3">Table Tennis</NavDropdown.Item>
              <NavDropdown.Divider />
              <NavDropdown.Item href="#action/3.4">
                Other Sport
              </NavDropdown.Item>
            </NavDropdown>
            <Link to="/contact" style={{padding:"15px", color:"black" ,textDecoration: 'none',fontFamily:"sans-serif"} }>Contact</Link>

          </Nav>
          <Nav>
          {/* <Link to="/register" style={{padding:"15px", color:"black",textDecoration: 'none',fontFamily:"sans-serif"} }>Registration</Link> */}
          <NavDropdown title="Login/Registration" id="navbarScrollingDropdown" style={{ paddingTop:"6px" ,fontSize:"16px",fontFamily:"sans-serif"}}>
            <NavDropdown.Item>
            <Link to="/register" style={{padding:"10px" ,color:"black",textDecoration: 'none',fontFamily:"sans-serif" ,}}>Registration</Link>
            </NavDropdown.Item>
              <NavDropdown.Item href="#action4">
              <Link to="/loginuser" style={{padding:"10px" ,color:"black",textDecoration: 'none',fontFamily:"sans-serif"}}>Userlogin</Link>
              </NavDropdown.Item>
              <NavDropdown.Item href="#action4">
              <Link to="/login" style={{padding:"10px" ,color:"black",textDecoration: 'none',fontFamily:"sans-serif"}}>Adminlogin</Link>
              </NavDropdown.Item>
              <NavDropdown.Divider />
              </NavDropdown>
              <Link to="/adminacc" style={{padding:"15px", color:"black" ,textDecoration: 'none',fontFamily:"sans-serif"} }>Admin</Link>

            <Link to="/account" style={{padding:"15px", color:"black" ,textDecoration: 'none',fontFamily:"sans-serif"} }>Account</Link>
            <Link to="/cart" style={{padding:"15px 20px", color:"black" ,textDecoration: 'none',fontFamily:"sans-serif"} }>Cart</Link>
            {/* <Nav.Link eventKey={2} href="#memes">Account</Nav.Link> */}
            {/* <Nav.Link eventKey={3} href="#memes">Cart</Nav.Link> */}
          </Nav>
        </Navbar.Collapse>
        <br /> <br />
      
    </Navbar>
    </div>
  );
}

export default Head;