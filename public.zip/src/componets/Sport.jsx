import React from 'react'
import Container from 'react-bootstrap/Container';
import Navbar from 'react-bootstrap/Navbar';
import Slider2 from'./Slider2';
import Signupform from './Signupform'
import Mid from'./midden';
import '../App.css';
import Addcard from "./Addcard";
// import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Cricket from './Cricket';
import Football from './Football';
import Badminton from './Badminton';

const sport = () => {
  return (
    <div>
     
         <Navbar fixed="top" />
      <Navbar className='sticky-top'  style={{backgroundColor:"#FFEECC" ,color:'white'}}>
        <Container>
          <Navbar.Brand href="#find0">Cricket</Navbar.Brand>
          <Navbar.Brand href="#find">Football</Navbar.Brand>
          <Navbar.Brand href="#find1">Badminton</Navbar.Brand>
          <Navbar.Brand href="#find1">Hockey</Navbar.Brand>
          <Navbar.Brand href="#find0">Base Ball</Navbar.Brand>
          <Navbar.Brand href="#find1">Others</Navbar.Brand>
          <Navbar.Brand href="#find">Hockey</Navbar.Brand>
          <Navbar.Brand href="#find1">Base Ball</Navbar.Brand>
          <Navbar.Brand href="#find">Others</Navbar.Brand>
        </Container>
        
      </Navbar>

      <Slider2/>
   
      

<div id='find0'>
<Mid
    name="Cricket"
    />  
</div>

<Cricket/>




    <div id='find'>
    <Mid
    name="Football"
    />  
    </div> 



    <Football/>


    <div id='find1'>
    <Mid
    name="Badminton"
    />  
    </div>
    
    <Badminton/>
     
    </div>
  )
}

export default sport
