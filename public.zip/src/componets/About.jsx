import React from 'react'

function About() {
  return (
    <div > 
      <br />
      <center>
     <h2 style={{backgroundColor:"#9EB8D9",padding:"10px 0 10px 0"}}><b>About Our Sportplus Store</b></h2> 
Welcome to [Your Sportplus Store Name], where freshness meets convenience! We take pride in providing a diverse selection of high-quality, fresh produce, pantry essentials, and more. Our commitment is to make grocery shopping an enjoyable experience for you and your family.
<div style={{padding:"30px"}}>

<h3><b>Our Mission</b></h3>
At [Your Grocery Store Name], our mission is to offer our customers the finest quality products sourced from local farmers and trusted suppliers. We aim to be your go-to destination for all your grocery needs, providing a one-stop-shop for fresh and delicious items.

<br /><br />
<h3><b>Freshness Guarantee</b></h3>
We understand the importance of fresh, wholesome ingredients in every meal. That's why we guarantee the freshness of our produce, dairy, meats, and other perishables. Our team works tirelessly to ensure that you receive only the best, ensuring that your meals are not just convenient but also delicious and nutritious.

<br /><br />
<h3><b>Community Engagement</b></h3>
We believe in giving back to the community that supports us. [Your Grocery Store Name] actively engages in community initiatives, supporting local farmers, and contributing to charitable organizations. By choosing us, you're not just shopping; you're joining a community that cares.

<br /><br />
<h3><b>Customer Service Excellence</b></h3>
Our dedicated team of friendly and knowledgeable staff is here to assist you. Whether you need help finding a specific item, have dietary questions, or want cooking tips, we're here for you. Your satisfaction is our top priority.

<br /><br />
<h3><b>Shop with Confidence</b></h3>
Rest assured that when you choose [Your Grocery Store Name], you are choosing a trusted partner in your culinary journey. We adhere to the highest standards of hygiene, safety, and quality, so you can shop with confidence.

Thank you for choosing [Your Grocery Store Name] as your preferred grocery destination. We look forward to serving you and becoming a part of your daily life.
<br />
</div>
<h3 style={{backgroundColor:"#9EB8D9",padding:"10px 0 10px 0"}}><b>Happy shopping!</b></h3>

 
 </center></div>
  )
}

export default About