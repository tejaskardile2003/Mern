import React from 'react';
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';

const Contact = () => {
  return (
    <div > 
       
        <br/><br /><center>
      <h2 style={{backgroundColor:"#9EB8D9",padding:"10px 0 10px 0"}}>Contact Us</h2>
      <br />
      <p>Have questions or concerns? We're here to help! Reach out to us using the information below:</p>
      <br />
      </center>
      <Container>
      <div >

      <Row>
        <Col xs={6} md={4}>
        <Card>
    <Card.Header as="h5" style={{backgroundColor:"#9EB8D9",padding:"10px 0 10px 0"}}><center>Customer Support</center></Card.Header>
    <Card.Body>
      <Card.Text>
      <p>If you need assistance with an order or have any questions about our products, please contact our customer support team.</p>        
        Email: <a href="mailto:aglawenikhil56@gmail.com" style={{textDecoration: 'none'}}>aglawenikhil56@gmail.com</a><br />
        Phone: <a href="tel:+123456789" style={{textDecoration: 'none'}}>8788747059</a>
      </Card.Text>
    </Card.Body>
  </Card>
        </Col>
        <Col xs={6} md={4}>
        <Card>
      <Card.Header as="h5" style={{backgroundColor:"#9EB8D9",padding:"10px 0 10px 0"}}><center>Visit Our Store</center></Card.Header>
      <Card.Body>
        <Card.Text>
        <p>Come visit our physical store to explore our wide range of fresh and quality products. Our friendly staff will be happy to assist you.</p>
        <address>
        <p style={{fontSize:"15px"}}> National Highway No.50 Govind Nagar, </p>
       <p style={{fontSize:"15px"}}> Near Bank of India ATM, </p>
        <p style={{fontSize:"15px"}}>Ahmednagar, </p>
        <p style={{fontSize:"15px"}}>Maharashtra 422605</p>
        </address>
        </Card.Text>
      </Card.Body>
    </Card>

        </Col>
        <Col xs={6} md={4}>
        <Card>
      <Card.Header as="h5" style={{backgroundColor:"#9EB8D9",padding:"10px 0 10px 0"}}><center>Connect With Us</center></Card.Header>
      <Card.Body>
        <Card.Text>
        <p>Stay updated and connected with us through our social media channels.</p>
       
       Facebook: <a href="https://www.facebook.com/example" style={{textDecoration: 'none'}}>facebook.com</a><br />
       WhatsApp: <a href="https://twitter.com/example" style={{textDecoration: 'none'}}>whtasapp.com</a><br />
       Instagram: <a href="https://www.instagram.com/example" style={{textDecoration: 'none'}}>instagram.com</a>
         </Card.Text>
      </Card.Body>
    </Card>
        </Col>
      </Row>
      <br />
<br /> 
</div>
      </Container>
    </div>
  );
};

export default Contact;