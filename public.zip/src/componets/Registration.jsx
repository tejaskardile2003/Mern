import axios from 'axios';
import { useState } from 'react';
import { Container } from 'react-bootstrap';
import Button from 'react-bootstrap/Button';
import Col from 'react-bootstrap/Col';
import Form from 'react-bootstrap/Form';
import InputGroup from 'react-bootstrap/InputGroup';
import Row from 'react-bootstrap/Row';

function Registration() {
  const [validated, setValidated] = useState(false);

  const[fname,setfname]=useState("");
  const[lname,setlname]=useState("");
  const[email,setemail]=useState("");
  const handleSubmit = (event) => {
  
    const setdata={
        fname:fname,
        lname:lname,
        email:email
    }
    axios.post("http://localhost:8000/abc/register",setdata)
    .then(res=>
        {
            console.log(res.data)
        })
    .catch((err)=>
    {
        console.log();
    })

    setValidated(true);
  };

  return (
    <Container>
        <Row>
        <Form noValidate validated={validated} onSubmit={handleSubmit}>
      <Row className="mb-3">
        <Form.Group as={Col} md="4" controlId="validationCustom01">
          <Form.Label>First name</Form.Label>
          <Form.Control
            required
            type="text"
            placeholder="First name"
            value={fname}
            onChange={(e)=>setfname(e.target.value)}/>
          <Form.Control.Feedback>Looks good!</Form.Control.Feedback>
        </Form.Group>
        <Form.Group as={Col} md="4" controlId="validationCustom02">
          <Form.Label>Last name</Form.Label>
          <Form.Control
            required
            type="text"
            placeholder="Last name"
            value={lname}
            onChange={(e)=>setlname(e.target.value)}
          />
          <Form.Control.Feedback>Looks good!</Form.Control.Feedback>
        </Form.Group>
        <Form.Group as={Col} md="4" controlId="validationCustomUsername">
          <Form.Label>EmailId</Form.Label>
          <InputGroup hasValidation>
            <InputGroup.Text id="inputGroupPrepend">@</InputGroup.Text>
            <Form.Control
              type="text"
              placeholder="Username"
              aria-describedby="inputGroupPrepend"
              required
              value={email}
              onChange={(e)=>setemail(e.target.value)}
            />
            <Form.Control.Feedback type="invalid">
              Please choose a Email
            </Form.Control.Feedback>
          </InputGroup>
        </Form.Group>
      </Row>
     
      <Button type="submit">Submit form</Button>
    </Form>
        </Row>
    </Container>
  );
}


export default Registration
