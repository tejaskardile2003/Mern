import Carousel from 'react-bootstrap/Carousel';
import React from "react";
import pic1 from './images/b.jpg'
import pic2 from './images/basket.jpeg'
import pic3 from './images/sport.jpg';
import pic5 from './images/sport2.jpg';
import pic6 from './images/sport3.jpg';
import Categories from './Categories';
import Ourservice from './Ourservice';
function Caro() {
  return (
    <div>
   
    <Carousel slide={false}>
      
      <Carousel.Item>
        <img src={pic5} alt="Picture(2)" width={"100%" } />
        <Carousel.Caption>
          {/* <h3>Second slide label</h3> */}
          {/* <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p> */}
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
       <img src={pic2} alt="Picture(1)" width={"100%" } />
        <Carousel.Caption>
          {/* <h3>First slide label</h3> */}
          {/* <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p> */}
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
       <img src={pic6} alt="Picture(1)" width={"100%" } />
        <Carousel.Caption>
          {/* <h3>First slide label</h3> */}
          {/* <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p> */}
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
       <img src={pic1} alt="Picture(1)" width={"100%" } />
        <Carousel.Caption>
          {/* <h3>First slide label</h3> */}
          {/* <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p> */}
        </Carousel.Caption>
      </Carousel.Item>
    </Carousel>
    <br /><br /><br />
    <Categories/>
    <br /><br /><br />
    <Ourservice/>
    </div>
  );
}

export default Caro;