import Container from 'react-bootstrap/esm/Container';
import React from "react";
import "./App.css"
import 'bootstrap/dist/css/bootstrap.min.css';
import Header from './componets/Header'
import Slide from './componets/Caro'
import Navexample from './componets/NavScrollExample'
 import Home from './componets/Cardss';
 import Fot from './componets/Fot';

import Team from "./componets/Team";
import Contact from "./componets/Contact";
import About from "./componets/About";
// import Home from "./componets/Home";
import Registration1 from './componets/Email';
import Registration from './componets/Registration';
import {Route,Routes,} from 'react-router-dom';
import Login from './componets/LoginPage';
import Loginuser from './componets/Loginuser';
import MoreProducts from './componets/Product';
import Demo1 from './componets/Demo1';
import Map from './componets/Map'
import Eff from './componets/Effectexample'
import Eff1 from './componets/Effectexa2'
import Eff2 from './componets/Effectexa3'
import Eff3 from './componets/Effectexa4'
import Hed from './componets/Head'
import Categories from './componets/Categories';
import Ourservice from './componets/Ourservice';
import Deatils from './componets/Deatils';
import Updating from './componets/Updating';
import Temp from './componets/Temp';
import Account from './componets/Account';
import Updateaccount from './componets/Updateaccount';
import Addcard from './componets/Addcard'
import Services from './componets/Sport';
import Cricket from './componets/Cricket'
import Shopcart from './componets/Shopcart';
import Tabledelet from './componets/Tabledelet';
import Signupform from './componets/Signupform';
import Adminacc from './componets/Adminacc'
import Tableproduct from './componets/Tableproduct';
import Tableproduct2 from './componets/Tableproduct2';
import Tableproduct3 from './componets/Tableproduct3';
const App = () => {
     

  return (
   
      // <>
      // <Container>
      // {/* <Navexample/> */}
      // <Header/>
      
        // <Routes>
        //    <Route path="/slide" element={<Slide/>}/>
        //    <Route path="/home" element={<Home/>}/>
        //    <Route path="/about" element={<About/>}/>
        //    <Route path="/team" element={<Team/>}/>
        //    <Route path="/contact" element={<Contact/>}/>
        //    <Route path="/register" element={<Registration/>}/>
        //    <Route path="/login" element={<Login/>}/>
        //    <Route path="/moreproducts" element={<MoreProducts/>}/>
        // </Routes>
      
      //   <Fot/>
      //   </Container>
      // </>
      // <>
      
      // <Hed/>
      // <Slide/>
      // <Categories/>
      // <Ourservice/>
      // <Fot/>
      // </>

      <>
      <Hed/>
     
      <Routes>
          <Route path="/" element={<Slide/>}/>
          <Route path="/home" element={<Slide/>}/>
          <Route path="/about" element={<About/>}/>
          <Route path="/contact" element={<Contact/>}/>
          <Route path="/services" element={<Services/>}/>
          <Route path="/register" element={<Registration1/>}/>
          <Route path="/login" element={<Login/>}/> 
          <Route path="/loginuser" element={<Loginuser/>}/> 
          <Route path="/account" element={<Account/>}/>
          <Route path="/updateaccount" element={<Updateaccount/>}/>
          <Route path="/tabledelet" element={<Tabledelet/>}/>
          <Route path="/adminacc" element={<Adminacc/>}/>
          <Route path="/addcard" element={<Addcard/>}/>
          <Route path="/cricket" element={<Cricket/>}/>
          <Route path="/cart" element={<Shopcart/>}/>
          <Route path="/cricket" element={<Tableproduct/>}/>
          <Route path="/football" element={<Tableproduct2/>}/>
          <Route path="/badminton" element={<Tableproduct3/>}/>
      </Routes>

 <Fot/>
      
      
      {/* <Deatils/>
      <Updating/> */}
      </>
  );
}

export default App;
